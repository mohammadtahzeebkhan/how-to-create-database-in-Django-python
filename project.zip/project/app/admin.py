from django.contrib import admin
from django.db import models
from .models import youtube

# Register your models here.
#admin.site.register(youtube)
@admin.register(youtube)
class show(admin.ModelAdmin):
    list_display=['id','name','rollno','dep']
